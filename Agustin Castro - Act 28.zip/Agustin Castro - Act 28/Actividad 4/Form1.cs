﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Interval = 10000;
        }
        int contador = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
            {
                timer1.Start();
                button1.Text = "Clickeá";
            }
                contador++;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            timer1.Stop();
            MessageBox.Show(contador.ToString());
        }
    }
}
