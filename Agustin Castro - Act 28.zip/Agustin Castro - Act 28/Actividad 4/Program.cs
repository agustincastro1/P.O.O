﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_4
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
/*
 4. Temporizador de Clics (Investigación: Timer)
● Investigación: Explicar el componente Timer (propiedades Interval, Enabled y
evento Tick) con un breve ejemplo explicativo.
● Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el
usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.
 */