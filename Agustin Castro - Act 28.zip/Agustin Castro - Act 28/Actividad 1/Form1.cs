﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num1, num2, num3;
            
            num1 = int.Parse(textBox1.Text);
            num2 = int.Parse(textBox2.Text);
            num3 = int.Parse(textBox3.Text);

            int promedio = 0;
            promedio = (num1 + num2 + num3) / 3;
            if (promedio >= 6)
            {
            label1.BackColor = Color.Green;
            }
            else
            {
                label1.ForeColor = Color.Red;
            }
            label1.Text = "Promedio: " + promedio;
            
        }
    }
}
