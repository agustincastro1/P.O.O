﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string plan = "";
            string servicios = "";
            if (checkBox1.Checked)
            {
                servicios = servicios + " Soporte Técnico";
            }
            if (checkBox2.Checked)
            {
                servicios = servicios + " Acceso Anticipado";
            }

            if (comboBox1.Text != "")
            {
                plan = plan + comboBox1.Text;
            }
            label1.Text = "Plan: " + plan + " Servicios:" + servicios;
        }
    }
}
