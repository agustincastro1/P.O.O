﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "";
            if (radioButton1.Checked)
            {
                label1.Text = label1.Text + "Playa ";
            }
            if (radioButton2.Checked)
            {
                label1.Text = label1.Text + "Montaña ";
            }
            if (radioButton3.Checked)
            {
                label1.Text = label1.Text + "Ciudad ";
            }
            if (comboBox1.Text != "")
            {
                label1.Text =label1.Text + comboBox1.Text;
            }
        }
    }
}
