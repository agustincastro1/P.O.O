﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Preferencias:";
            string txt = "";
            if (checkBox1.Checked)
            {
                txt = txt + " Escuchar en vivo";
            }
            if (checkBox2.Checked)
            {
                txt = txt + " Escuchar en streaming";
            }
            if (checkBox3.Checked)
            {
                txt = txt + " Comprar discos";
            }
            if (comboBox1.Text != "")
            {
                txt = txt + " " + comboBox1.Text;
            }
            label1.Text += txt;
        }
    }
}
