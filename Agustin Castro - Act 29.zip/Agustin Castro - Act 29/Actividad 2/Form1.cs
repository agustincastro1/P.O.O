﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            numericUpDown1.Minimum = 0; 
            numericUpDown1.Maximum = 255;
            numericUpDown2.Minimum = 0; 
            numericUpDown2.Maximum = 255;
            numericUpDown3.Minimum = 0; 
            numericUpDown3.Maximum = 255;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            decimal rojo = numericUpDown1.Value;
            decimal verde = numericUpDown2.Value;
            decimal azul = numericUpDown3.Value;
            this.BackColor = Color.FromArgb((int)rojo,(int)verde,(int)azul);
        }
    }
}
