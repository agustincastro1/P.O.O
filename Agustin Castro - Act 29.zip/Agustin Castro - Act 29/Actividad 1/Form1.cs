﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int total = 0;
            if (checkBox1.Checked)
            {
                total = total + 25;
            }
            if (checkBox2.Checked)
            {
                total = total + 67;
            }
            if (checkBox3.Checked)
            {
                total = total + 89;
            }

            label1.Text = "total: " + total.ToString();
            total = 0;
        }
    }
}
