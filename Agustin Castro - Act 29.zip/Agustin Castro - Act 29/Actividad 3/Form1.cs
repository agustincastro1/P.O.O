﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox2.UseSystemPasswordChar = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked && textBox1.Text != "" && textBox2.Text == "admin123")
            {
                label3.Text = "exito";
            }
            else
            {
                label3.Text = "advertencia";
            }
        }
    }
}
